// V2 wraps the generated sequence; it never changes its values or units.
pub const MAX_PACKET_BYTES: usize = 255;
pub const HEADER_BYTES: usize = 29; // M2:<16 hex ID>:<8 hex CRC32>:
pub const MAX_WAYPOINTS: usize = 10;
// Must match the A3.1 Mega's A31_MAX_STEP_MS = 60000 and desktop MAX_LEG_S.
pub const MAX_TIMED_LEG_SECONDS: f64 = 60.000;
pub const MIN_TIMED_LEG_SECONDS: f64 = 0.100;

pub fn validate_sequence(sequence: &str) -> Result<(), String> {
    // A3.1 Mega supervised forward-only command. Accept a single bounded TF
    // token, never arbitrary motion or a silently chained route.
    if let Some(seconds) = sequence.strip_prefix("TF") {
        if sequence.len() > 9 || seconds.is_empty() ||
            !seconds.bytes().all(|b| b.is_ascii_digit() || b == b'.') ||
            seconds.bytes().filter(|b| *b == b'.').count() > 1 ||
            !seconds.parse::<f64>().is_ok_and(|n| n.is_finite() && (MIN_TIMED_LEG_SECONDS..=MAX_TIMED_LEG_SECONDS).contains(&n)) {
            return Err("Timed movement must be a single TF0.100–TF60.000 command.".into());
        }
        return Ok(());
    }
    if !sequence.is_ascii()
        || sequence.len() > MAX_PACKET_BYTES - HEADER_BYTES
        || !sequence.starts_with("N1,")
    {
        return Err(
            "Expected N1 waypoint targets in at most 226 ASCII bytes. No route was truncated."
                .into(),
        );
    }
    let mut tokens = sequence.split(',').skip(1).peekable();
    if tokens.peek().is_some_and(|t| t.starts_with('H')) {
        let token = tokens.next().unwrap();
        let number = &token[1..];
        if token.len() > 8
            || number.is_empty()
            || !number.bytes().all(|b| b.is_ascii_digit() || b == b'.')
            || !number
                .parse::<f64>()
                .is_ok_and(|n| n.is_finite() && (0.0..360.0).contains(&n))
        {
            return Err("Invalid optional true-north heading reference.".into());
        }
    }
    let mut count = 0;
    for token in tokens {
        let coords = token
            .strip_prefix('W')
            .ok_or("Only waypoint targets are accepted after N1 and optional H.")?;
        let (lat, lon) = coords
            .split_once('.')
            .ok_or("W requires two encoded coordinate integers.")?;
        let integer = |s: &str, max: u32| {
            !s.is_empty()
                && s.len() <= 9
                && s.bytes().all(|b| b.is_ascii_digit())
                && s.parse::<u32>().is_ok_and(|n| n <= max)
        };
        if !integer(lat, 180000000) || !integer(lon, 360000000) {
            return Err("Invalid waypoint coordinates.".into());
        }
        count += 1;
    }
    if count == 0 || count > MAX_WAYPOINTS {
        return Err("Mission requires 1-10 waypoint targets within 226 bytes.".into());
    }
    Ok(())
}

pub fn checksum(payload: &str) -> u32 {
    let mut crc = !0u32;
    for byte in payload.bytes() {
        crc ^= byte as u32;
        for _ in 0..8 {
            crc = (crc >> 1) ^ (0xEDB88320u32 & 0u32.wrapping_sub(crc & 1));
        }
    }
    !crc
}

pub fn key(id: u64, crc: u32) -> String {
    format!("{id:016X}:{crc:08X}")
}
pub fn frame(id: u64, sequence: &str) -> String {
    format!("M2:{}:{sequence}", key(id, checksum(sequence)))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn crc_and_transport_are_unchanged() {
        assert_eq!(checksum("123456789"), 0xCBF43926);
        assert_eq!(
            frame(1, "123456789"),
            "M2:0000000000000001:CBF43926:123456789"
        );
    }
    #[test]
    fn bounded_straight_leg_does_not_permit_unbounded_motion() {
        for s in ["TF0.100", "TF0.250", "TF1.500", "TF2.000", "TF20.000", "TF45.000", "TF60.000"] {
            assert!(validate_sequence(s).is_ok(), "{s}");
        }
        for s in ["TF0.099", "TF60.001", "TF61.000", "TF60.000,TF1.000", "TL0.500", "TR0.500", "TFNaN", "TF", "TF1..0", "TF-1", "TF1e3"] {
            assert!(validate_sequence(s).is_err(), "{s}");
        }
    }
    #[test]
    fn targets_upload_without_gps_heading_or_calibration() {
        for s in [
            "N1,W104609000.300989000",
            "N1,H0,W0.0",
            "N1,H359.99,W180000000.360000000",
        ] {
            assert!(validate_sequence(s).is_ok(), "{s}");
        }
        for s in [
            "",
            "N1",
            "N1,",
            "N1,W0.0,",
            "N1,H360,W0.0",
            "N1,HNaN,W0.0",
            "N1,F1,W0.0",
            "N1,W180000001.0",
            "N1,W0.360000001",
            "F1,W0.0",
            "TIME:F1",
        ] {
            assert!(validate_sequence(s).is_err(), "{s}");
        }
        assert!(validate_sequence(&format!("N1{}", ",W104609000.300989000".repeat(10))).is_ok());
        assert!(validate_sequence(&format!("N1{}", ",W104609000.300989000".repeat(11))).is_err());
    }
}
