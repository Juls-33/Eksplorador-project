# Regression evidence — Map GPS-loss continuity

Date: 2026-11-20

- 8/8 automated Node.js tests passed on isolated source fixtures.
- Dry-run and backup/idempotence covered.
- Confirmed no patch to embedded firmware, database, or soil GPS state.
- Pure utility tests cover first and last allowed milliseconds, timeout after 30s, disconnected receiver, invalid zero/NaN/out-of-range coordinates, and backwards timestamps.
- Passed TypeScript JSX syntax diagnostics for both patched JSX fixtures and both new JS utility/hook files where the TypeScript parser is available; the Node.js test runner has no TypeScript dependency.
- Tested compatibility with a FieldMapView fixture containing the earlier DATA GPS planning fallback.

**Scope of verification:** This is not a production build against the user's full local repository, nor a hardware GPS-loss validation. Run `npm run build` locally, then check the live receiver behavior.

**Technical limitation:** Last-known position retention is not odometry-based dead reckoning; it is an intentionally conservative stopgap to prevent sudden disappearance without claiming an uncalibrated moving estimate.
