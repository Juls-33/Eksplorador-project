'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs=require('fs');
const os=require('os');
const path=require('path');
const {main,patchField,patchMap}=require('../apply_gps_continuity.js');
const payload=path.join(__dirname,'..','payload');
const baselineField=`import PointToPointMissionDialog from '../components/PointToPointMissionDialog';
export default function FieldMapView(){
  const [roverHeading, setRoverHeading] = useState(null);
  const [roverPos, setRoverPos] = useState(null);
  // The following should remain unchanged for soil GPS validity:
  if (hasValidGps) {
    setRoverPos([lat, lng]);
    gpsExpiry.current = setTimeout(() => setRoverPos(null), 5000);
  } else { setRoverPos(null); }
  return <div><HeatmapMap roverPos={roverPos}
              roverPos={roverPos}/>
            {/* Map-centered sampling chip: shown during active mission logging, not in the sidebar. */}
  </div>;
}`;
// The real map contains one marker prop. Avoid the demonstration above's duplicated prop.
const field=baselineField.replace('<HeatmapMap roverPos={roverPos}\n              roverPos={roverPos}/>','<HeatmapMap\n              roverPos={roverPos}/>');
const map=`export default function HeatmapMap({
  roverPos = [14.6095, 120.9895],
  showRover = true
}) {
  useEffect(() => {
    if (showRover && hasMapPosition(roverPos)) {
      roverMarkerRef.current.setLatLng(roverPos);
      doMap();
    }
  }, [roverPos, showRover]);
}`;
function fixture(){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'eksplorador-display-'));
 const write=(p,s)=>{const f=path.join(root,p);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,s);};
 write('apps/desktop/src/views/FieldMapView.jsx',field);
 write('apps/desktop/src/components/HeatmapMap.jsx',map);
 write('embedded/mega/Mega_Keep.ino','// stable original firmware\n');
 write('apps/desktop/src/services/db.js','// stable database\n');
 return {root,write};
}
test('map display patch retains original soil-GPS state',()=>{
 const out=patchField(field);
 assert.match(out,/setRoverPos\(null\)/);
 assert.match(out,/const roverDisplay = useRoverDisplayPosition/);
 assert.match(out,/roverPos=\{roverDisplay.position\}/);
 assert.match(out,/not dead reckoning/);
 assert.match(out,/roverDisplay.mode === 'LAST_KNOWN'/);
 assert.doesNotMatch(out,/setRoverPos\(roverDisplay/);
});
test('marker code distinctly labels stale map position',()=>{
 const out=patchMap(map);
 assert.match(out,/setOpacity\(isLastKnown \? 0.45 : 1\)/);
 assert.match(out,/roverPositionStatus/);
 assert.match(out,/Last known GPS position/);
});
test('installation is dry-run, idempotent, with backups and no embedded edits',()=>{
 const {root}=fixture();const say=()=>{};
 try{
  main(root,true,say);
  assert.equal(fs.existsSync(path.join(root,'apps/desktop/src/hooks/useRoverDisplayPosition.js')),false);
  main(root,false,say);
  const changed=fs.readFileSync(path.join(root,'apps/desktop/src/views/FieldMapView.jsx'),'utf8');
  assert.match(changed,/EKSPLORADOR_GPS_DISPLAY_CONTINUITY_V1/);
  main(root,false,say);
  assert.equal(fs.readFileSync(path.join(root,'apps/desktop/src/views/FieldMapView.jsx'),'utf8'),changed);
  assert.equal(fs.readFileSync(path.join(root,'embedded/mega/Mega_Keep.ino'),'utf8'),'// stable original firmware\n');
  assert.equal(fs.readFileSync(path.join(root,'apps/desktop/src/services/db.js'),'utf8'),'// stable database\n');
 }finally{fs.rmSync(root,{recursive:true,force:true});}
});
test('bad source aborts with no partial writes',()=>{
 const {root,write}=fixture();
 try{
  write('apps/desktop/src/components/HeatmapMap.jsx','// mismatched source');
  assert.throws(()=>main(root,false,()=>{}),/expected exactly one/);
  assert.equal(fs.readFileSync(path.join(root,'apps/desktop/src/views/FieldMapView.jsx'),'utf8'),field);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
});
test('supports FieldMapView with prior GPS mission fix active',()=>{
 const src=field.replace('const [roverHeading, setRoverHeading] = useState(null);',
  'const [roverHeading, setRoverHeading] = useState(null);\n  const [telemetryNavGps, setTelemetryNavGps] = useState(null);');
 assert.match(patchField(src),/const \[telemetryNavGps, setTelemetryNavGps\]/);
});
test('supports Windows CRLF source',()=>{
 const {root,write}=fixture();
 try{
  write('apps/desktop/src/views/FieldMapView.jsx',field.replace(/\n/g,'\r\n'));
  write('apps/desktop/src/components/HeatmapMap.jsx',map.replace(/\n/g,'\r\n'));
  main(root,false,()=>{});
  assert.match(fs.readFileSync(path.join(root,'apps/desktop/src/views/FieldMapView.jsx'),'utf8'),/\r\n/);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
});
// Import pure client utility without requiring a React or Vite runtime.
test('last-known 30-second window, invalid fixes and receiver disconnect',async()=>{
 const raw=fs.readFileSync(path.join(payload,'roverPositionDisplay.js'),'utf8');
 const m=await import('data:text/javascript;base64,'+Buffer.from(raw).toString('base64'));
 const last={position:[14.6,120.9],receivedAt:1000};
 for(const age of [0,1000,5000,29999,30000]){
  const out=m.resolveLastKnownGpsDisplay(last,1000+age,true);
  assert.equal(out.mode,'LAST_KNOWN');
  assert.deepEqual(out.position,[14.6,120.9]);
  assert.equal(out.ageMs,age);
 }
 for(const age of [30001,60000]){
  assert.equal(m.resolveLastKnownGpsDisplay(last,1000+age,true).mode,'UNAVAILABLE');
 }
 assert.equal(m.resolveLastKnownGpsDisplay(last,2000,false).mode,'UNAVAILABLE');
 assert.equal(m.resolveLastKnownGpsDisplay({position:[0,0],receivedAt:1000},2000,true).mode,'UNAVAILABLE');
 assert.equal(m.resolveLastKnownGpsDisplay({position:[NaN,120],receivedAt:1000},2000,true).mode,'UNAVAILABLE');
 assert.equal(m.resolveLastKnownGpsDisplay({position:[91,120],receivedAt:1000},2000,true).mode,'UNAVAILABLE');
 assert.equal(m.resolveLastKnownGpsDisplay(last,999,true).mode,'UNAVAILABLE');
});
let ts = null;
try { ts = require('typescript'); } catch (_) { /* Optional: the user does not need TypeScript for the installer tests. */ }
test('patched JSX and hook syntax (TypeScript JSX diagnostics if available)',()=>{
 for(const [name,src] of [
  ['FieldMapView.jsx',patchField(field)],
  ['HeatmapMap.jsx',patchMap(map)],
  ['useRoverDisplayPosition.js',fs.readFileSync(path.join(payload,'useRoverDisplayPosition.js'),'utf8')],
  ['roverPositionDisplay.js',fs.readFileSync(path.join(payload,'roverPositionDisplay.js'),'utf8')],
 ]) {
  assert.ok(src.length > 50, name + ': unexpectedly empty');
  if (ts) {
    const out=ts.transpileModule(src,{fileName:name,reportDiagnostics:true,
     compilerOptions:{allowJs:true,jsx:ts.JsxEmit.Preserve,target:ts.ScriptTarget.ES2020,module:ts.ModuleKind.ESNext}});
    const errs=(out.diagnostics||[]).filter(x=>x.category===ts.DiagnosticCategory.Error);
    assert.equal(errs.length,0,name+': '+errs.map(e=>ts.flattenDiagnosticMessageText(e.messageText,' ')).join('; '));
  }
 }
});
