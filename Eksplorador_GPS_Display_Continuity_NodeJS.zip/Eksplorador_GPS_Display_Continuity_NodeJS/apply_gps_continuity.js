#!/usr/bin/env node
'use strict';
// Stdlib-only, dry-run-first, fail-closed updater. No embedded files are touched.
const fs = require('fs');
const path = require('path');
const ROOT = path.resolve(process.argv.find((x, i) => i > 1 && !x.startsWith('--')) || '.');
const DRY = process.argv.includes('--dry-run');
const MARKER = 'EKSPLORADOR_GPS_DISPLAY_CONTINUITY_V1';

function replaceUnique(src, before, after, name) {
  const first = src.indexOf(before);
  if (first < 0 || src.indexOf(before, first + before.length) >= 0) {
    throw new Error(`${name}: expected exactly one matching code anchor; found ${first < 0 ? 0 : 'multiple'}. No project files changed.`);
  }
  return src.slice(0, first) + after + src.slice(first + before.length);
}
function patchField(input) {
  let src = input;
  src = replaceUnique(src,
    "import PointToPointMissionDialog from '../components/PointToPointMissionDialog';",
    "import PointToPointMissionDialog from '../components/PointToPointMissionDialog';\n" +
    "import { useRoverDisplayPosition } from '../hooks/useRoverDisplayPosition.js'; // " + MARKER,
    'FieldMapView: GPS display hook import');
  src = replaceUnique(src,
    '  const [roverHeading, setRoverHeading] = useState(null);',
    `  const [roverHeading, setRoverHeading] = useState(null);
  // Map-only last-known fix. Keep roverPos null on GPS loss so soil geotags
  // and Point A never accidentally receive a historical position.
  const roverDisplay = useRoverDisplayPosition(
    roverPos, receiverStatus.connected && !receiverStatus.connectionError
  );`,
    'FieldMapView: display-only hook call');
  src = replaceUnique(src,
    '              roverPos={roverPos}',
    '              roverPos={roverDisplay.position}\n              roverPositionStatus={roverDisplay.mode}',
    'FieldMapView: HeatmapMap display props');
  const overlayAnchor = '            {/* Map-centered sampling chip: shown during active mission logging, not in the sidebar. */}';
  src = replaceUnique(src, overlayAnchor,
    `            {roverDisplay.mode === 'LAST_KNOWN' && (
              <div role="status" aria-live="polite" style={{
                position: 'absolute', top: 12, left: 12, zIndex: 790,
                maxWidth: 'min(355px, calc(100% - 24px))',
                padding: '8px 12px', borderRadius: 8,
                border: '1px solid #d97706', background: '#fffbeb',
                color: '#92400e', fontSize: 13, lineHeight: 1.4,
                pointerEvents: 'none', boxShadow: '0 2px 8px rgba(0,0,0,.1)'
              }}>
                <strong>GPS unavailable — last known location</strong>
                <div>{Math.floor(roverDisplay.ageMs / 1000)}s since last GPS fix · Not live, not dead reckoning</div>
              </div>
            )}
` + overlayAnchor,
    'FieldMapView: map warning overlay');
  return src;
}
function patchMap(input) {
  let src=input;
  src=replaceUnique(src,
    '  roverPos = [14.6095, 120.9895],',
    '  roverPos = [14.6095, 120.9895],\n  roverPositionStatus = \'GPS\', // ' + MARKER,
    'HeatmapMap: display status prop');
  src=replaceUnique(src,
    '      roverMarkerRef.current.setLatLng(roverPos);',
    `      roverMarkerRef.current.setLatLng(roverPos);
      // Last-known coordinates are NOT current GPS or odometry.
      const isLastKnown = roverPositionStatus === 'LAST_KNOWN';
      roverMarkerRef.current.setOpacity(isLastKnown ? 0.45 : 1);
      roverMarkerRef.current.bindTooltip(isLastKnown
        ? 'Last known GPS position (not live, not dead reckoning)'
        : 'Live GPS rover position');`,
    'HeatmapMap: distinguish held marker');
  src=replaceUnique(src,
    '  }, [roverPos, showRover]);',
    '  }, [roverPos, showRover, roverPositionStatus]);',
    'HeatmapMap: refresh marker status');
  return src;
}
const PATCHES = [
  { rel:'apps/desktop/src/views/FieldMapView.jsx', fn:patchField },
  { rel:'apps/desktop/src/components/HeatmapMap.jsx', fn:patchMap },
  { rel:'apps/desktop/src/utils/roverPositionDisplay.js', payload:'roverPositionDisplay.js' },
  { rel:'apps/desktop/src/hooks/useRoverDisplayPosition.js', payload:'useRoverDisplayPosition.js' },
];
function main(root=ROOT, dry=DRY, log=console.log) {
  const planned=[];
  for (const p of PATCHES) {
    const absolute = path.resolve(root,p.rel);
    if (!absolute.startsWith(root + path.sep)) throw new Error('Path escapes project: '+p.rel);
    const exists=fs.existsSync(absolute);
    const original=exists? fs.readFileSync(absolute,'utf8') : null;
    if(p.fn && !exists)throw new Error(`Missing ${p.rel}. No project files changed.`);
    if(p.payload && exists) {
      const desired=fs.readFileSync(path.join(__dirname,'payload',p.payload),'utf8');
      if(original!==desired)throw new Error(`Existing ${p.rel} differs from bundled version. No project files changed.`);
      planned.push({p,absolute,already:true});
      continue;
    }
    if(p.fn && original.includes(MARKER)) {
      planned.push({p,absolute,already:true});
      continue;
    }
    const crlf=original?.includes('\r\n');
    const stripped=original?.replace(/\r\n/g,'\n');
    const result=p.fn ? p.fn(stripped) : fs.readFileSync(path.join(__dirname,'payload',p.payload),'utf8');
    planned.push({p,absolute,already:false,original,output:crlf ? result.replace(/\n/g,'\r\n') : result});
  }
  for(const item of planned) log(`${item.already?'ALREADY PATCHED':dry?'WOULD PATCH':'PATCH'}: ${item.p.rel}`);
  if (dry || planned.every(x=>x.already)) { log(dry?'Dry run complete; no files changed.':'Already installed; no files changed.');return; }
  const backups=path.join(__dirname,'backups',new Date().toISOString().replace(/[:.]/g,'-'));
  fs.mkdirSync(backups,{recursive:true});
  // Back up every existing file before committing any changes.
  for (const item of planned.filter(x=>!x.already && x.original!==null)) {
    const save=path.join(backups,item.p.rel);
    fs.mkdirSync(path.dirname(save),{recursive:true});
    fs.writeFileSync(save,item.original);
  }
  const written=[];
  try {
    for(const item of planned.filter(x=>!x.already)){
      fs.mkdirSync(path.dirname(item.absolute),{recursive:true});
      fs.writeFileSync(item.absolute,item.output);
      written.push(item);
    }
  } catch (error) {
    for (const item of written.reverse()) {
      if (item.original===null) fs.rmSync(item.absolute,{force:true});
      else fs.writeFileSync(item.absolute,item.original);
    }
    throw new Error(`Write failed; restored earlier writes: ${error.message}`);
  }
  log('Done. Changes are display-only; GPS validity, soil geotags, missions, and embedded firmware unchanged.');
  log(`Backups: ${backups}`);
}
if (require.main===module){try{main();}catch(e){console.error('ERROR: '+e.message);process.exitCode=1;}}
module.exports={main,patchField,patchMap};
