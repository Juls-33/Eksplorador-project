# Eksplorador — GPS-loss Map Continuity (desktop only)

This is a **low-risk first stage of GPS-loss continuity**. It is intentionally **NOT true dead reckoning**. The rover's current FUS telemetry includes encoder RPM and yaw rate but no calibrated track-distance-to-ground-motion model or validated initial heading; extrapolating a moving position would mislead the operator. Instead, the desktop map shows the **last verified GPS coordinates for up to 30 seconds** after the last valid satellite-confirmed fix, marked as **NOT LIVE**. The marker is semi-transparent and an amber notice shows age since the last fix. At 30 seconds the marker disappears unless GPS returns earlier.

## What remains 100% unchanged

- Mega motor-control and timed-mission firmware; ESP32 rover and receiver firmware.
- Point A → Point B mission planning and safety limits; current semi-autonomous speed calibration.
- The original `roverPos` live GPS state in FieldMapView, the 5-second GPS validity timeout, satellite checks, and `telemetryNavGps` used by the recent GPS mission fix.
- Soil sampling, GPS-verified sample geotags, manual geotag fallback, LoRa telemetry, database, and heatmap calculations.

The *new* `roverDisplay` value is fed **only** to the FieldMap's visual rover marker; it is never persisted or used for navigation, missions, or sensor data.

## Installation on Windows with Node.js

Extract **the full `Eksplorador_GPS_Display_Continuity_NodeJS` folder** into:

`D:\UST Capstone\Eksplorador-project\`

From PowerShell at the project root:

```powershell
node .\Eksplorador_GPS_Display_Continuity_NodeJS\apply_gps_continuity.js . --dry-run
```

Expect `WOULD PATCH` for exactly 4 desktop files and no changes made. **If the dry run fails, do not force it**. Share its error; source versions may differ.

After checking the four paths:

```powershell
node .\Eksplorador_GPS_Display_Continuity_NodeJS\apply_gps_continuity.js .
cd apps\desktop
npm run build
npm run tauri dev
```

Optional standalone tests, from the project root:

```powershell
node --test .\Eksplorador_GPS_Display_Continuity_NodeJS\tests\regression.cjs
```

The installer is idempotent. It checks all anchors before editing anything, and backs up original files under the installer folder before writing. It requires **no Python and no npm dependency for installation**.

## Real receiver test

1. In the field, connect the desktop receiver and obtain valid GPS coordinates (>0 `satsLocked`); Field Map's normal rover pin should be solid.
2. Simulate a short GPS outage **without turning off the receiver**. The map should preserve the previous coordinates with an amber `GPS unavailable — last known location` warning and a semi-transparent marker. There is **no position movement or extrapolation**.
3. Check that soil-sampling UI correctly says `GPS unavailable` during the loss and does not label held coordinates as an actual GPS sample.
4. If valid GPS returns within 30 seconds, map immediately returns to the current solid GPS position.
5. If GPS stays unavailable for over 30 seconds, the held marker disappears. A disconnected desktop receiver clears it immediately.
6. If the rover is moving, the held dot can be inaccurate: **do not use it for mission selection, waypoint driving, or soil geotagging**.

## Changed files

- `apps/desktop/src/views/FieldMapView.jsx` — calls a new display-only hook and shows the warning.
- `apps/desktop/src/components/HeatmapMap.jsx` — renders a faded marker and a correct tooltip for last-known GPS.
- `apps/desktop/src/hooks/useRoverDisplayPosition.js` — maintains a separate 30-second visual cache.
- `apps/desktop/src/utils/roverPositionDisplay.js` — pure coordinate validation and timeout logic.

There is **no persistent storage, no LoRa format change, and no hardware testing required for the first application build**. End-to-end GPS-loss behavior with the real receiver still requires verification.
