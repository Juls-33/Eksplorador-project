#pragma once
// Eksplorador A2.9: pure C++ LOGIC MODEL, NOT connected to motor PWM.
// All sensor confirmations are explicit inputs. Never infer that a
// probe retracted based on tilt alone or after waiting a fixed time.
#include <stdint.h>
namespace Workflow {
  enum class Phase : uint8_t {
    IDLE, STAGED, NAVIGATE, HOLD_LOCALIZATION, ARRIVAL_STOP,
    EXTEND, SAMPLE, RETRACT, HOLD_SAFETY, COMPLETE, ABORT
  };
  struct Config {
    uint32_t maxDrAgeMs = 300;
    float maxUncertaintyM = 2.0f; // DEMO ONLY: requires team calibration
    uint32_t extensionTimeoutMs = 3000; // DEMO ONLY
    uint32_t sampleTimeoutMs = 8000; // DEMO ONLY
    uint32_t retractTimeoutMs = 4000; // DEMO ONLY
  };
  struct Input {
    bool rcAuthorized = false;
    bool manualOverride = false;
    bool abortRequested = false;
    bool gpsFresh = false;
    bool deadReckoningValid = false;
    uint32_t drAgeMs = 0;
    float uncertaintyM = 9999;
    bool encoderFresh = false;
    bool obstacleClear = false;
    bool imuFresh = false;
    bool tiltWithinLimit = false;
    bool driveStopped = false;
    bool arrived = false;
    bool probeContactVerified = false;
    bool soilSampleFreshAndValid = false;
    bool probeRetractedConfirmed = false;
  };
  struct Outputs { bool drive = false; bool extend = false; bool retract = false; };
  class Supervisor {
    Config cfg_;
    Phase phase_ = Phase::IDLE;
    uint32_t enteredMs_ = 0;
    bool calibrated_ = false;
    bool hasPermission_ = false;
  public:
    explicit Supervisor(Config cfg = Config{}) : cfg_(cfg) {}
    Phase phase() const {return phase_;}
    void stage(uint32_t now) {phase_=Phase::STAGED; enteredMs_=now; hasPermission_=false;}
    void permitCalibrationForSimulation(bool calibrated) {calibrated_=calibrated;}
    void authorizeForSimulation(bool operatorApproved) {hasPermission_=operatorApproved;}
    bool localizationUsable(const Input& in) const {
      const bool drSafe = in.deadReckoningValid && in.encoderFresh && in.imuFresh &&
        in.drAgeMs <= cfg_.maxDrAgeMs &&
        in.uncertaintyM >= 0 && in.uncertaintyM <= cfg_.maxUncertaintyM;
      return in.gpsFresh || drSafe; // GPS loss != automatically fatal.
    }
    Outputs update(uint32_t now, const Input& in) {
      if (in.manualOverride || in.abortRequested || !in.rcAuthorized) {
        if (phase_ != Phase::IDLE && phase_ != Phase::COMPLETE)
          phase_=Phase::ABORT;
        return {};
      }
      if (phase_ == Phase::STAGED) {
        if (!calibrated_ || !hasPermission_ || !in.probeRetractedConfirmed) return {};
        phase_=Phase::NAVIGATE;enteredMs_=now;
      }
      if (phase_ == Phase::NAVIGATE) {
        if (!in.probeRetractedConfirmed || !in.encoderFresh || !in.obstacleClear) {
          phase_=Phase::HOLD_SAFETY;enteredMs_=now;return {};
        }
        if (!localizationUsable(in)) {
          phase_=Phase::HOLD_LOCALIZATION;enteredMs_=now;return {};
        }
        if (in.arrived) {phase_=Phase::ARRIVAL_STOP;enteredMs_=now;return {};}
        return {true,false,false};
      }
      if (phase_ == Phase::HOLD_LOCALIZATION) {
        if (localizationUsable(in) && in.probeRetractedConfirmed &&
            in.obstacleClear && in.encoderFresh) {
          // Requires explicit reauthorization on any localization hold.
          phase_=Phase::STAGED;hasPermission_=false;enteredMs_=now;
        }
        return {};
      }
      if (phase_ == Phase::ARRIVAL_STOP) {
        if (in.driveStopped && in.imuFresh && in.tiltWithinLimit) {
          phase_=Phase::EXTEND;enteredMs_=now;
        }
        return {};
      }
      if (phase_ == Phase::EXTEND) {
        if (!in.driveStopped || !in.imuFresh || !in.tiltWithinLimit ||
            uint32_t(now-enteredMs_) > cfg_.extensionTimeoutMs) {
          phase_=Phase::HOLD_SAFETY;enteredMs_=now;return {};
        }
        if (in.probeContactVerified) {
          phase_=Phase::SAMPLE;enteredMs_=now;return {};
        }
        return {false,true,false};
      }
      if (phase_ == Phase::SAMPLE) {
        if (!in.imuFresh || !in.tiltWithinLimit || !in.driveStopped ||
            uint32_t(now-enteredMs_) > cfg_.sampleTimeoutMs) {
          phase_=Phase::HOLD_SAFETY;enteredMs_=now;return {};
        }
        if (in.soilSampleFreshAndValid) {
          phase_=Phase::RETRACT;enteredMs_=now;
        }
        return {};
      }
      if (phase_ == Phase::RETRACT) {
        if (!in.driveStopped || !in.imuFresh ||
            uint32_t(now-enteredMs_) > cfg_.retractTimeoutMs) {
          phase_=Phase::HOLD_SAFETY;enteredMs_=now;return {};
        }
        if (in.probeRetractedConfirmed) {
          phase_=Phase::COMPLETE;enteredMs_=now;return {};
        }
        return {false,false,true};
      }
      return {};
    }
  };
}
