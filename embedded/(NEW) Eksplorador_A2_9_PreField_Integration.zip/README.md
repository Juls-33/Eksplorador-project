# Eksplorador A2.9 — Mission Integrity / Pre-Field Safety Prototype

Based on: user-supplied `Eksplorador-project-main(1).zip`, directory `embedded/1 Final Microcontroller Firmwares (unuploaded)/`, plus application code as present in that ZIP. This is **not** a fully calibrated autonomous mission release.

## What's here

- `embedded/mega/Mega_A2_9/Mega_A2_9.ino`: Existing Mega firmware with **additional mission ID/status handling** and a default-false autonomous actuation guard. Manual RC, actuator tilt/recovery, Modbus soil, encoders, ultrasound, Serial2 remain the original implementations (no changes to their core routines).
- `embedded/rover/Rover_A2_9/Rover_A2_9.ino`: Existing rover ESP32 A2.7 with the Mission V2 ID preserved during UART handoff; receives and periodically retransmits the latest Mega mission status when radio TX. Existing IMU, GPS, `DATA`, `ENC`, `FUS`, ACK2 and NVS journal preserved.
- `embedded/desktop/Receiver_A2_9/Receiver_A2_9.ino`: Existing receiver ESP32 A2.7 with additional `MS:` -> `type=missionStatus` JSON demultiplexing.
- `embedded/shared/MissionProtocol.h`: **byte-identical** to uploaded shared header. Do not delete; relative `../../shared/MissionProtocol.h` includes depend on the provided folder structure.
- `design/MissionWorkflow.h`: **host-testable, NON-ACTUATING logic model**, not wired into Mega PWM. Documents GPS-loss/DR, stop, probe, soil, retract and safe-state transitions for Codex and future integration. Its thresholds are DEMO PLACEHOLDERS.
- `tests/*.cpp`: host checks for Mission V2 CRC logic, mission stage safety and status parser. `diff_*.patch`: exact firmware changes. `CODEX_PROMPT.md`: ready-to-send app instructions.

## Message contract

Existing PC -> receiver USB -> LoRa Mission V2: `M2:<ID16>:<CRC8>:<sequence>`. Unchanged.

Existing Rover -> PC `ACK2:<ID16>:<CRC8>`: **radio receipt and UART queued**, not Mega validation. Unchanged.

**New Rover -> Mega UART:** `RCV2:<ID16>:<sequence>` instead of `RCV:<sequence>` for Mission V2 only.

**New Mega -> Rover UART:** `MS:<ID16>:<revision>:<state>:<step>:<reason>`, repeated every 2.5 seconds while status exists.

**New Rover -> Receiver LoRa:** relays matching `MS` frames best-effort after switching back to TX; repeats last status approximately every 2.2 sec while TX and DATA ACK isn't pending. If the desktop radio remains in TX, it cannot receive these statuses. No new hardware pin wiring.

**New Receiver USB JSON:** `{"type":"missionStatus","missionId":"0123456789ABCDEF","statusSeq":1,"state":"STAGED","step":0,"reason":"NAV_NOT_CALIBRATED","rssi":-40,"snr":8.5}`.

Current Mega status states: `STAGED`, `REJECTED`, and `HELD` (if an old execution path would otherwise engage). The staged mission is not executed. Invalid legacy `RCV:` missions are rejected. No automatic actuator or drive commands are issued from uploaded missions in this build.

## Recommended upload and bench test (motor battery disconnected)

1. Save a GitHub backup/commit of the previously working A2.7 + strengthened RC-failsafe firmware and desktop app. Confirm exact hardware-flashed versions before upgrading.
2. Extract the package without moving sketches away from their relative `shared` header path. Choose **Mega 2560** for `Mega_A2_9.ino`, and **ESP32 Dev Module** for both ESP32 sketches.
3. In Arduino IDE **Verify** each sketch before upload; this package has not been compiled against Arduino cores in this environment. Fix reported compile errors before testing, not by weakening guards.
4. Upload the three sketches **as a coordinated set**. Motor/actuator power must stay disconnected for mission tests. Verify the usual RC, SOIL, IMU, GPS, DATA, ENC and FUS telemetry logs remain correct.
5. Use the existing Mission V2 deployment wizard (with original app) to send a normal command sequence via its existing workflow, when the UI can produce a sequence. It sends the same V2 envelope; no new desktop parser needed merely to transmit. Ensure Mega is in a safe disarmed/nonmoving state.
6. Observe Rover USB for `[MISSION V2] UART queued`, and Mega USB for `[A2.9] Mission STAGED only...`. Once both LoRa endpoints return to their normal telemetry roles, verify Rover USB `[MEGA STATUS LoRa TX]` and receiver USB `{"type":"missionStatus",..."STAGED"...}`. The original app may NOT show this JSON until Codex implements the new parser.
7. Confirm **no drive or actuator PWM changes due to mission receipt**. Test malformed/stale/duplicate mission IDs in a software/mock environment; never bypass existing NVS duplicate protection on hardware.
8. Check manual RC works as before, and disarm/reconnect inhibits stale motor commands. Use normal independent hardware emergency-stop provision. Then return to stable version if any regression occurs.

## What remains before physical autonomous field testing

- Actual, error-bounded GPS+IMU+encoder dead reckoning is NOT implemented. A2.7 is an observer. GPS loss should cause DR-based continuation **only after** DR validity, scale, yaw bias, track slip and confidence limits are measured. Otherwise HOLD_LOCALIZATION with no movement, not an irreversible GPS fault.
- Loaded track displacement calibration and effective turn separation remain unknown.
- Actual position-based arrival, waypoint-matched sample requests and autonomous actuator cycle are NOT enabled. IMU detects unsafe tilt; it cannot directly measure actuator load/contact or verify fully retracted probe. Calibrate mechanical limits and obtain independent clearance confirmation or require an operator-gated movement policy.
- Hardware actuator overload sensing remains disabled in the source; do not claim it is protected by current sensing. Keep the already-tested bounded tilt recovery, and independently assess mechanical protection.
- Bench sonar still uses no-echo permissive mode for MANUAL testing; before autonomous field movement, missing/invalid echoes must be handled safely.
- LoRa mission-status frames are **repeated best-effort**, not individually ACKed. Build idempotent desktop handling and consider eventual reliable status transfer/journaling.
- Physical E-stop, driver enable pin startup state, power integrity, RC receiver fail-safe settings, off-ground field boot tests and uncertainty-based stop conditions need field verification.

## What we verified here

- 28 unchanged safety/sensor/telemetry helper functions compared exactly with the ZIP originals.
- Cross-sketch source checks, structural C++ brace/literal balance and protocol invariants passed.
- Host C++ workflow/CRC test passed (23 assertions); status parser test passed.
- **No Arduino core/compiler, firmware upload, RF hardware test or full desktop build was available in this environment.** Do not call this build verified for deployment.

See `AUDIT.md` for risks and `CODEX_PROMPT.md` for the current desktop application updates.
