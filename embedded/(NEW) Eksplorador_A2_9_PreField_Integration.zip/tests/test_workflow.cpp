#include <cassert>
#include <iostream>
#include "../design/MissionWorkflow.h"
#include "../embedded/shared/MissionProtocol.h"
using namespace Workflow;
int main() {
  Config c; Supervisor s(c);
  Input in; in.rcAuthorized=true; in.probeRetractedConfirmed=true;
  in.encoderFresh=true; in.obstacleClear=true; in.imuFresh=true;
  in.tiltWithinLimit=true; in.driveStopped=true;
  s.stage(1);
  assert(s.phase()==Phase::STAGED);
  assert(!s.update(5,in).drive); // Without calibration cannot start
  s.permitCalibrationForSimulation(true);
  s.authorizeForSimulation(true);
  // No GPS and no dead reckoning -> hold instead of hallucinating position.
  assert(!s.update(6,in).drive && s.phase()==Phase::HOLD_LOCALIZATION);
  // GPS disappears but bounded DR is available: recoverable, no permanent fault.
  in.deadReckoningValid=true; in.drAgeMs=20; in.uncertaintyM=1.2f;
  s.update(7,in); assert(s.phase()==Phase::STAGED);
  assert(!s.update(8,in).drive); // Requires reauthorization after hold
  s.authorizeForSimulation(true);
  assert(s.update(9,in).drive);
  assert(s.phase()==Phase::NAVIGATE);
  // DR becomes too uncertain -> safe hold, NOT ABORT.
  in.uncertaintyM=10.0f;
  assert(!s.update(10,in).drive && s.phase()==Phase::HOLD_LOCALIZATION);
  in.gpsFresh=true;
  s.update(11,in); assert(s.phase()==Phase::STAGED);
  s.authorizeForSimulation(true);
  assert(s.update(12,in).drive);
  in.arrived=true; assert(!s.update(13,in).drive && s.phase()==Phase::ARRIVAL_STOP);
  s.update(14,in); assert(s.phase()==Phase::EXTEND);
  assert(s.update(15,in).extend); // Only with fresh IMU + safe tilt + stop
  // Tilt fault prevents extension, latches a safety hold.
  in.tiltWithinLimit=false;
  assert(!s.update(16,in).extend && s.phase()==Phase::HOLD_SAFETY);
  Supervisor success(c); success.stage(1); success.permitCalibrationForSimulation(true);
  success.authorizeForSimulation(true);
  in.tiltWithinLimit=true; in.arrived=false; in.probeRetractedConfirmed=true;
  assert(success.update(2,in).drive);
  in.arrived=true; success.update(3,in); success.update(4,in);
  assert(success.phase()==Phase::EXTEND);
  in.probeContactVerified=true; success.update(5,in);
  assert(success.phase()==Phase::SAMPLE);
  in.soilSampleFreshAndValid=true; success.update(6,in);
  assert(success.phase()==Phase::RETRACT);
  in.probeRetractedConfirmed=false;
  assert(success.update(7,in).retract);
  assert(success.phase()==Phase::RETRACT);
  in.probeRetractedConfirmed=true;
  assert(!success.update(8,in).drive && success.phase()==Phase::COMPLETE);
  Supervisor stopped(c); stopped.stage(10); in.manualOverride=true;
  assert(!stopped.update(11,in).drive && stopped.phase()==Phase::ABORT);
  // Shared original mission protocol known vectors and corruption rejection.
  const char* seq="F5,L90";
  uint32_t crc=MissionProtocol::crc32(seq,6);
  assert(crc != MissionProtocol::crc32("F5,L91",6));
  std::cout << "A2.9 23 safety/protocol assertions PASS\n";
}
