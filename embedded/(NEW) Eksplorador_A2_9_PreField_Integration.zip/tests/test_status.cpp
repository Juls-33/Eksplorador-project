#include <cstdio>
#include <cstring>
#include <cassert>
#include <iostream>
int main() {
 const char *good[]={
  "MS:0000ABCDEF123456:1:STAGED:0:NAV_NOT_CALIBRATED",
  "MS:0000ABCDEF123456:2:REJECTED:0:SAFETY_LATCHED",
  "MS:0000ABCDEF123456:99:HELD:2:LOCALIZATION_HOLD"};
 for(auto s:good) {
  char id[17]={}, state[22]={},reason[34]={};unsigned long revision=0;unsigned step=0;int end=0;
  int n=std::sscanf(s,"MS:%16[0-9A-F]:%lu:%21[A-Z_]:%u:%33[A-Z_]%n",id,&revision,state,&step,reason,&end);
  assert(n==5 && end==(int)std::strlen(s) && std::strlen(id)==16 && step<=50);
 }
 const char* bad="MS:ABCD:1:STAGED:0:NONE";
 char id[17]={},state[22]={},reason[34]={};unsigned long revision=0;unsigned step=0;int end=0;
 int n=std::sscanf(bad,"MS:%16[0-9A-F]:%lu:%21[A-Z_]:%u:%33[A-Z_]%n",id,&revision,state,&step,reason,&end);
 assert(n!=5 || std::strlen(id)!=16 || end!=(int)std::strlen(bad));
 std::cout<<"Mission status grammar PASS\n";
}
