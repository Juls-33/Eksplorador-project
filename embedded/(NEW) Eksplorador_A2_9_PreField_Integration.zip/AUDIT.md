# A2.9 Source Audit — 2026-11-03

## Core findings (from supplied project ZIP)

| Finding | Impact | A2.9 disposition |
|---|---|---|
| Desktop `OperatorNavGuide.jsx` emits `R/L/F` distances/turns using assumed starting course | Not feedback-controlled navigation, no actual waypoint arrival | Do not execute; staged receipt only. Codex prompt defines future versioned waypoint protocol |
| Mega transforms meters/degrees into 200–2500 ms timing, not calibrated distance | Can mistake a short burst for reaching a pin | Hard autonomous lock applied at `processAutoDrive()` entry |
| No automatic stop → IMU-safe deploy → fresh soil sample → retract → clearance → next pin | No real autonomous soil sampling | Design-only pure C++ mission workflow with tests; **not** actuator-enabled |
| IMU tilt detection is not force, position or contact sensing | Retraction confirmation not available | Existing tilt stop/recovery preserved; simulation requires explicit clearance; no unattended auto deployment |
| GPS unavailable in indoor environment; A2.7 observer is not DR | Losing GPS during motion currently has no validated fallback | Design treats GPS loss as recoverable if bounded DR is fresh; otherwise HOLD without motion |
| V2 `ACK2` means Rover UART queued | Desktop could falsely show completed deployment | Preserve ACK2, deliver separate Mega-sourced `MS` mission state. App Codex prompt requires separate statuses |
| Rover NVS journal survives reboot | Duplicate mission delivery avoided, but outcome unknown on reset window | Existing reserve/queue decision preserved. Status mapped to matching Mission V2 ID |
| A2.7 DATA/ENC/FUS sometimes differs in reception frequency | Dashboard RPM may show fusion fallback without encoder counter update | Existing radio/sensor frames unchanged; status repeated best effort. End-to-end validation pending |
| Sonar bench no-echo treated as clear | Unsafe for outdoor unattended autonomous behavior | Autonomous locked; manual calibration behavior preserved. Field config still requires revision |
| Actuator current overload `false` | Not guarded by calibrated current trip | No false claims; original IMU mechanism unchanged, independent position/endstop required for autonomy |
| RC channel timeout/rearm and manual override exist | Must not be regressed | Original manual, output interlock and tilt/recovery functions unchanged. Firmware should still be bench verified |
| LoRa mode is half duplex and RC CH8 controls roles | Status may arrive only after mode switched back to telemetry | Mega periodically repeats status; Rover TX retransmits last accepted status; receiver converts to JSON |

## Detailed review scope

- Mega `semi-autonomous.ino`: ISR PWM freshness, RC state machine, manual motor polarities, three BTS7960 drivers, tilt faults/manual retract, ultrasonic and detour, Modbus soil sensor, encoder tick ISR and RPM UART, mission validation/bench executor.
- Rover `Rover_A2_7.ino`: UART mission handoff and IMU deferral, NVS duplicate protection, LoRa radio role switching, GPS/IMU acquisition, DATA ACK/retries, ENC and FUS best effort, Mission V2 ACK2 and NACK2.
- Receiver `Receiver_A2_7.ino`: Serial commands, async Mission V2 sending, radio mode, DATA ACK, sensor JSON, ENC and FUS JSON.
- Shared `MissionProtocol.h`: CRC32, ID parsing, payload bounds, airtime, NVS record stages.
- Desktop (read only): `OperatorNavGuide.jsx`, `MissionDeploymentWizard.jsx`, `FieldMapView.jsx`, Rust `mission_deployment.rs`, `mission_protocol.rs`, `serial_lines.rs`.

## Source changes in this artifact

1. Mega uses `RCV2:<id>:<sequence>` for V2 and validates/records as **STAGED**, with a status ID and revision. It rejects old `RCV:`. It cannot automatically actuate because `A29_ALLOW_AUTONOMOUS_ACTUATION=false` and `processAutoDrive` refuses all motion in its state.
2. Rover sends `RCV2` instead of `RCV` while preserving NVS exactly-once handoff logic, parses one-line Mega `MS`, checks it against current journal ID, and repeats the latest state over LoRa when in TX.
3. Receiver parses `MS` into bounded, escaped-free JSON fields from a constrained uppercase alphabet. It does not alter DATA/ENC/FUS processing.
4. `MissionWorkflow.h` is an isolated executable **simulation model**, NOT active motor code. It demonstrates a recovery hold on GPS loss with fresh bounded DR, explicit stopped/IMU-safe extension gating, soil sample confirmation, retraction confirmation and abort/override behavior. Thresholds must not be copied into production without calibration.
5. Desktop is **NOT modified here**; use Codex to integrate in the current working tree. The desktop code in ZIP may predate your latest Codex app fixes.

## Audit limitations and blockers

- No complete Arduino ESP32/Mega cross-compilation or hardware-in-loop tests were possible here. The source-level/host-model tests do not rule out board-specific compilation errors, timing issues, ISR contention, LoRa collisions, SRAM exhaustion, radio loss or physical hazards.
- The exact flashed firmware version on all boards must be confirmed by your team; the provided ZIP directory is labeled `(unuploaded)`.
- True field-calibrated dead reckoning cannot be manufactured from the existing A2.7 observer. It needs actual measured track distance, slip and gyro bias, plus confidence bounds and independent motion checkpoints.
- The user preference to use IMU tilt protection is respected, but it cannot prove full probe clearance. For an autonomous system, safe retraction verification is still a prerequisite; in its absence, a supervised/manual confirmation step must remain mandatory and physical autonomy disabled.
- Mission status periodic retransmission is not a fully durable exactly-once Mega acceptance ledger; future release should journal Mega mission outcomes and ACK status or use a request/response state query.
- Review motor driver EN pins, pull-downs, power and emergency stop separately; firmware cannot eliminate all transient boot electrical issues.

## Regression plan

1. Arduino IDE Verify Mega and both ESP32 firmware sources, after backing up all working versions.
2. USB-only RC receiver off/on/disarm/rearm (motor supply disconnected): ensure outputs remain zero until deliberate arm, manual commands unchanged when armed.
3. Soil RS485 polling, GPS validity (no fix indoors expected), IMU valid and tilt-fault cancellation; encoders, RPM, `DATA`, `ENC`, `FUS` unchanged.
4. Mission V2 send through app with valid project-generated ID: check `ACK2` means queued and `MS:...STAGED...NAV_NOT_CALIBRATED` from Mega reaches the laptop only after roles return to RX/TX.
5. Wrong/malformed mission: rejection with matching ID where possible; never motion.
6. Duplicate/replayed M2: no second UART delivery; rover journal not cleared.
7. Hold tests: valid bounded DR on GPS loss (host model), stale encoder/gyro/uncertainty -> HOLD_LOCALIZATION; never auto-resume without operator authorization.
8. Simulated stop/extend/soil/retract: no actuator on stale IMU, no drive with probe unconfirmed, abort/manual override immediate; no actuation test in this release.
9. Desktop app regression testing with Codex: status matching, parsing, stale/dedup logic and 19-field DATA compatibility.
10. Only after calibrated navigation and actuator endstops/clearance checks: controlled one-waypoint physical trial with full safety supervisor and emergency-stop procedure.
